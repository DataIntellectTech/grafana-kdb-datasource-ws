/// <reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />
declare var _default: {
    create: (part: any) => any;
};
export default _default;
