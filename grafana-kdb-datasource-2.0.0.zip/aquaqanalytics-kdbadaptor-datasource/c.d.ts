export declare class C {
    u8u16(u16: any): any[];
    u16u8(u8: any): string;
    deserialize(x: any): any;
    serialize(x: any): ArrayBuffer;
}
