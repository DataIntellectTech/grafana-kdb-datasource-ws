export class ConflationParams {
    val: string;
    agg: string;
}
