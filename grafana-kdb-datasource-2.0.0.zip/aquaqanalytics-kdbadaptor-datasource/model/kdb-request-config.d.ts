export declare const defaultRowCountLimit: number;
export declare var defaultTimeout: number;
export declare const kdbEpoch: number;
export declare const durationMap: {
    ms: number;
    s: number;
    m: number;
    h: number;
};
export declare const graphFunction: string;
export declare const tabFunction: string;
export declare const argCounter: string;
