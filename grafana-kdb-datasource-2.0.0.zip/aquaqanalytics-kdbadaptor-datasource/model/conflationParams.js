System.register([], function(exports_1) {
    var ConflationParams;
    return {
        setters:[],
        execute: function() {
            ConflationParams = (function () {
                function ConflationParams() {
                }
                return ConflationParams;
            })();
            exports_1("ConflationParams", ConflationParams);
        }
    }
});
//# sourceMappingURL=conflationParams.js.map