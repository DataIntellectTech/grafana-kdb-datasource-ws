System.register([], function(exports_1) {
    var wsState;
    return {
        setters:[],
        execute: function() {
            wsState = (function () {
                function wsState() {
                }
                return wsState;
            })();
            exports_1("wsState", wsState);
        }
    }
});
//# sourceMappingURL=wsState.js.map