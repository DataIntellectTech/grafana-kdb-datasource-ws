export declare class QueryDictionary {
    type: string;
    value: string;
}
