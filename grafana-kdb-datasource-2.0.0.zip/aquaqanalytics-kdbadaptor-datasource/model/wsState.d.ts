export declare class wsState {
    lastResponse: Date;
    awaitingResponse: boolean;
    currentQuerySendTime: Date;
    connecting: boolean;
}
