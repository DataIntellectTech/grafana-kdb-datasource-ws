System.register([], function(exports_1) {
    var KdbRequest;
    return {
        setters:[],
        execute: function() {
            KdbRequest = (function () {
                function KdbRequest() {
                }
                return KdbRequest;
            })();
            exports_1("KdbRequest", KdbRequest);
        }
    }
});
//# sourceMappingURL=kdb-request.js.map