export class QueryDictionary {
    type: string;
    value: string;
}
