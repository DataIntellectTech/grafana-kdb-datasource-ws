System.register([], function(exports_1) {
    var QueryDictionary;
    return {
        setters:[],
        execute: function() {
            QueryDictionary = (function () {
                function QueryDictionary() {
                }
                return QueryDictionary;
            })();
            exports_1("QueryDictionary", QueryDictionary);
        }
    }
});
//# sourceMappingURL=queryDictionary.js.map