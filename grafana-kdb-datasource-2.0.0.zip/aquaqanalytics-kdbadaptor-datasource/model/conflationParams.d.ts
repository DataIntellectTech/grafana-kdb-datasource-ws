export declare class ConflationParams {
    val: string;
    agg: string;
}
