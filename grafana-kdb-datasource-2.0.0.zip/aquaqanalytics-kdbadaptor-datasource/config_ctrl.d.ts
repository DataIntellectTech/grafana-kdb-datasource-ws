/// <reference path="../node_modules/grafana-sdk-mocks/app/headers/common.d.ts" />
export declare class KDBConfigCtrl {
    static templateUrl: string;
    current: any;
    constructor($scope: any, backendSrv: any, $q: any);
}
